//:   **🎮🕹👾Mini Games👾🕹🎮**
//: =
/*:- - -*/
//: **Info**
//: =
//: **The Game**
//: -
//: Mini Games consists three of the most famous  **👾Arcade games👾**  namely :- **Tic Tac Toe, Pong and Color Jump**
//: ###
/*:
 - **Pong**  →  Pong is a two-dimensional sports game that simulates table tennis🏓. The player controls an in-game paddle🚣 by moving it vertically across right side of the screen.
 - **Tic-Tac-Toe**  →  Tic-tac-toe, also called noughts and crosses or ❌s and ⭕️s is a game for two people. The board 🎲(which can be a drawing on a paper or other place) consists of a square◼️ that is crossed by two vertical and two horizontal lines, so in total there are three small squares left in the top line, another 3 in the center line and 3 more in the bottom line.
 - **Color Jump**  → 🔴🟠🟡🟢. It is a tap tap game inspired by the famous "Color Switch" App. Follow the colour pattern to cross each obstacle🔴🟠🟡🟢.
 */
/*:- - -*/
//: **Me**
//: =
//: Hello! My name is **Stvya Sharma**. I'm 16 years old who belong to Jammu, India🇮🇳 and I'm currently studying in 📚12th📚 Grade. I have a keen interest in mathematics🧮 and computer💻 because through computers I can turn my whole imaginative worlds of creations into real life and mathematics is my drug as it challenges me at every question.
//: ###
/*:- - -*/
//: **How To Play**
//: =
/*:
 - **Pong**  →  Controls the in-game paddle by pressing the the upper and bottom half of the screen.
 - **Tic-Tac-Toe**  →Each player takes turns drawing a cross or a circle in a square (or placing tokens of different shapes or colors) The winner is the one who manages to place three equal pieces in a row, either vertically, horizontally or diagonally. **To Exit the game swipe right!!!**
 - **Color Jump**  →  Tap Tap the screen to move the ball. The ball can only pass the obstacle by going through the part of the obstacle that has the same color as the ball.
 */
/*:- - -*/
//: **Code**
//: =
//: ## Packages
    import PlaygroundSupport
    import SpriteKit
    import SwiftUI
    import AVFoundation
    import UIKit
//: ## Main Page
    public struct MainPage: View {
        // Starting Page
        public var body: some View {
            VStack{
                ZStack{
                    Image(uiImage: #imageLiteral(resourceName: "wordart.png"))
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 380)
                }
                ZStack{
                    HStack{
                    VStack{
                        ZStack{
                            //Tic-Tac-Toe Image Button
                            Button(action: openTicTacToe){
                                Image(uiImage: #imageLiteral(resourceName: "tictactoe.png"))
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: 150)
                                    .padding(10)
                            }
                            
                        }
                        ZStack{
                            //Tic-Tac-Toe Name Button
                            Button(action : openTicTacToe){
                                Text("Tic Tac Toe").font(.title2)
                            }
                        }
                        ZStack{
                            //Color Jump Image Button
                            Button(action: openColorJump){
                                Image(uiImage: #imageLiteral(resourceName: "Color Jump.png"))
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: 150)
                                    .padding(10)
                            }
                        }
                        ZStack{
                            //Color Jump Name Button
                            Button(action : openColorJump){
                                Text("Color Jump").font(.title2)
                            }
                        }
                    }
                    HStack{
                        VStack{
                            ZStack{
                                //Pong Image Button
                                Button(action: openPong){
                                    Image(uiImage: #imageLiteral(resourceName: "Pong.png"))
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(width: 150)
                                        .padding(10)
                                }
                            }
                            ZStack{
                                //Pong Name Button
                                Button(action : openPong){
                                    Text("Pong").font(.title2)
                                }
                            }
                        }
                        }
                    }
                }}
            }
        }

//: ## Main Page Theme Song
    var audioPlayer: AVAudioPlayer?
    // Main Page theme Song
    func playboop() {
        if let audioURL = Bundle.main.url(forResource: "Main theme", withExtension: "m4a") {
            do {
                try audioPlayer = AVAudioPlayer(contentsOf: audioURL)
                audioPlayer?.numberOfLoops = 0//Number of Loops
                audioPlayer?.play()
            } catch {
                print("Couldn't play audio. Error: \(error)")
            }
        } else {
            print("No audio file found")
        }
    }
    playboop()
//: ## Main Page Button Functions
//:### Main Page View

let viewController =  MainPage().frame(width: 400,height:600).background(Color(.black))
    PlaygroundPage.current.setLiveView(viewController)
    func openMainPage(){
        var viewController =  MainPage().frame(width: 400,height:600).background(Color(.black))
        PlaygroundPage.current.setLiveView(viewController)
    }
//:### Function to open Color Jump
    func openColorJump() {
        let scene = GameScene(size: CGSize(width: 480, height: 640))
        scene.scaleMode = .aspectFill
        let view = SKView(frame: CGRect(x:0, y:0, width: scene.size.width, height: scene.size.height))
        view.presentScene(scene)
        PlaygroundPage.current.liveView = view
    }
//:### Function to open Tic-Tac-Toe
    func openTicTacToe() {
        PlaygroundSupport.PlaygroundPage.current.setLiveView(thisGame())
    }
//:### Function to open Pong
    func openPong() {
        let PongView = SKView(frame: CGRect(origin: CGPoint.zero, size: CGSize(width: 400, height: 600)))
        let Pongscene = gameScene(size: CGSize(width: 800, height: 1200))
        Pongscene.backgroundColor =
            UIColor(red:130.0/255.0, green:210.0/255.0, blue:220.0/255.0, alpha:1.0)
        PongView.presentScene(Pongscene)
        PlaygroundPage.current.liveView =  PongView
    }
    
//: ## Color Jump
    public class GameScene: SKScene, SKPhysicsContactDelegate {
//: ### Physics
        struct PhysicsCategory{
            static let Player: UInt32 = 1
            static let Obstacles: UInt32 = 2
        }
        
        let player = SKShapeNode(circleOfRadius: 20)
        let obstacleSpacing: CGFloat = 800
        let cameraNode = SKCameraNode()
        let HighScoreLabel = SKLabelNode()
        let backButton = SKLabelNode()
        var Highscore = 0
//: ### Starting Function
        public func didBegin(_ contact: SKPhysicsContact) {
            if let nodeA = contact.bodyA.node as? SKShapeNode, let nodeB = contact.bodyB.node as? SKShapeNode{
                if nodeA.fillColor != nodeB.fillColor{
                    player.physicsBody?.velocity.dy = 0
                    player.removeFromParent()
                    score = 0
                    HighScoreLabel.text = String("High Score : \(Highscore)")
                    backButton.text = "Back"
                    scoreLabel.text = String(score)
                    let colours = [UIColor.yellow, UIColor.red, UIColor.blue, UIColor.purple]
                    addPlayer(colour: colours.randomElement()!)
                }
                if nodeA.fillColor == nodeB.fillColor{
                    score += 1
                    self.sound(sound: "Color Switch Bounce", type: "mp3", loops: 0)
                    
                    if Highscore < score {
                        Highscore = score
                    }
                    
                    HighScoreLabel.text = String("High Score : \(Highscore)")
                    scoreLabel.text = String(score)
                    
                }
            }
        }
//: ### Adding Player
        func addPlayer(colour: UIColor){
            player.fillColor = colour
            player.strokeColor = player.fillColor
            player.position = CGPoint(x: 0, y: -100)
            //Physics Properties
            let playerBody = SKPhysicsBody(circleOfRadius: 15)
            playerBody.mass = 1.5
            playerBody.categoryBitMask = PhysicsCategory.Player
            playerBody.collisionBitMask = 4
            player.physicsBody = playerBody
            //Add to scene
            addChild(player)
        }
        
//: ### Circle Obstacle
        func addCircle(yHeight : Int){
            let path = UIBezierPath()
            path.move(to: CGPoint(x: 0, y: -200))
            path.addLine(to: CGPoint(x:0, y: -160))
            path.addArc(withCenter: CGPoint.zero, radius:160, startAngle: CGFloat(3.0 * (Double.pi / 2)), endAngle: CGFloat(0), clockwise: true)
            path.addLine(to: CGPoint(x: 200, y: 0))
            path.addArc(withCenter: CGPoint.zero, radius: 200, startAngle: CGFloat(0.0), endAngle: CGFloat(3.0 * (Double.pi / 2)), clockwise: false)
            let obstacle = SKNode()
            for i in 0...3{
                let colours = [UIColor.yellow, UIColor.red, UIColor.blue, UIColor.purple]
                let section = SKShapeNode(path: path.cgPath)
                section.position = CGPoint(x: 0, y: 0)
                section.fillColor = colours[i]
                section.strokeColor = colours[i]
                section.zRotation = CGFloat(Double.pi / 2) * CGFloat(i);
                //Physics Properties
                let sectionBody = SKPhysicsBody(polygonFrom: path.cgPath)
                sectionBody.categoryBitMask = PhysicsCategory.Obstacles
                sectionBody.collisionBitMask = 0
                sectionBody.contactTestBitMask = PhysicsCategory.Player
                sectionBody.affectedByGravity = false
                section.physicsBody = sectionBody
                //Add to Obstacle
                obstacle.addChild(section)
            }
            obstacle.position = CGPoint(x: 0, y: yHeight)
            addChild(obstacle)
            let rotateAction = SKAction.rotate(byAngle: 2.0 * CGFloat(Double.pi), duration: 8.0)
            obstacle.run(SKAction.repeatForever(rotateAction))
        }
//: ### Square Obstacle
        func addSquare(yHeight : Int){
            let path = UIBezierPath(roundedRect: CGRect(x: -200, y: -200, width: 400, height: 40), cornerRadius: 20)
            let obstacle = SKNode()
            for i in 0...3{
                let colours = [UIColor.yellow, UIColor.red, UIColor.blue, UIColor.purple]
                let section = SKShapeNode(path: path.cgPath)
                section.position = CGPoint(x: 0, y: 0)
                section.fillColor = colours[i]
                section.strokeColor = colours[i]
                section.zRotation = CGFloat(Double.pi / 2) * CGFloat(i);
                //Physics Properties
                let sectionBody = SKPhysicsBody(polygonFrom: path.cgPath)
                sectionBody.categoryBitMask = PhysicsCategory.Obstacles
                sectionBody.collisionBitMask = 0
                sectionBody.contactTestBitMask = PhysicsCategory.Player
                sectionBody.affectedByGravity = false
                section.physicsBody = sectionBody
                //Add to Obstacle
                obstacle.addChild(section)
            }
            obstacle.position = CGPoint(x: 0, y: yHeight)
            addChild(obstacle)
            let rotateAction = SKAction.rotate(byAngle: -2.0 * CGFloat(Double.pi), duration: 8.0)
            obstacle.run(SKAction.repeatForever(rotateAction))
        }
        let scoreLabel = SKLabelNode()
        var score = 0
//: ### Function to add Obstacles
        func addObstacle() {
            var i = 200
            while i < 10000 {
                if i % 200 == 0 {
                    addCircle(yHeight: i)
                }else{
                    addSquare(yHeight: i)
                }
                i += 900
                
            }
        }
        let colours = [UIColor.yellow, UIColor.red, UIColor.blue, UIColor.purple]
//: ### Movement of Player
        public override func didMove(to view: SKView) {
            physicsWorld.contactDelegate = self
            physicsWorld.gravity.dy = -22
            
            addPlayer(colour: .red)
            
            addChild(cameraNode)
            camera = cameraNode
            cameraNode.position = player.position
            
            scoreLabel.position = CGPoint(x: 0, y: 200)
            scoreLabel.fontColor = .white
            scoreLabel.fontSize = 100
            scoreLabel.text = String(score)
            backButton.fontColor = .white
            backButton.position = CGPoint(x: 200, y: -300)
            backButton.fontSize = 20
            backButton.fontName = "AvenirNext-Bold"
            HighScoreLabel.position = CGPoint(x:0, y:-300)
            HighScoreLabel.fontName = "AvenirNext-Bold"
            HighScoreLabel.fontSize = 30
            HighScoreLabel.fontColor = .white
            HighScoreLabel.text = String("High Score : \(Highscore)")
            backButton.text = "Back"
            cameraNode.addChild(scoreLabel)
            cameraNode.addChild(backButton)
            cameraNode.addChild(HighScoreLabel)
            addObstacle()
            sound(sound: "Color Jump theme", type: "m4a", loops: 10000)
        }
        public override func update(_ currentTime: TimeInterval) {
            let playerPositionInCamera = cameraNode.convert(player.position, to: self)
            if playerPositionInCamera.y > 0 && !cameraNode.hasActions(){
                cameraNode.position.y = player.position.y
            }
            if player.position.y <= -350 {
                player.physicsBody?.isDynamic = true
                player.physicsBody?.velocity.dy = 600.0
            }
        }
        public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            player.physicsBody?.velocity.dy = 600.0
            for touch in touches {
                let location = touch.location(in: self)
                if location.y <= -290 && location.x >= 190{
                    openMainPage()
                }
            }
        }
//: ### Color Jump Music
        var arrayOfPlayers = [AVAudioPlayer]()
        func sound(sound: String, type: String, loops: Int) {
            do {
                if let bundle = Bundle.main.path(forResource: sound, ofType: type) {
                    let alertSound = NSURL(fileURLWithPath: bundle)
                    try AVAudioSession.sharedInstance().setCategory(AVAudioSession.Category.ambient)
                    try AVAudioSession.sharedInstance().setActive(true)
                    let audioPlayer = try AVAudioPlayer(contentsOf: alertSound as URL)
                    audioPlayer.numberOfLoops = loops
                    arrayOfPlayers.append(audioPlayer)
                    arrayOfPlayers.last?.prepareToPlay()
                    arrayOfPlayers.last?.play()
                }
            } catch {
                print(error)
            }
        }
        
    }
//: ## Pong
//: ### Declaration of Constant
    // Declare some global constants
    let width = 800 as CGFloat
    let height = 1200 as CGFloat
    let racketHeight = 150 as CGFloat
    let ballRadius = 20 as CGFloat
    // Three types of collision objects possible
    enum CollisionTypes: UInt32 {
        case Ball = 1
        case Wall = 2
        case Racket = 4
    }
    // Racket direction
    enum RacketDirection: Int{
        case None = 0
        case Up = 1
        case Down = 2
    }
//: ### SpriteKit scene
    // SpriteKit scene
    public class gameScene: SKScene, SKPhysicsContactDelegate {
        let racketSpeed = 500.0
        var direction = RacketDirection.None
        var score = 0
        var HighScore = 0
        var gameRunning = false
        // Screen elements
        var racket: SKShapeNode?
        var ball: SKShapeNode?
        let backButton = SKLabelNode()
        let scoreLabel = SKLabelNode()
        let HighScoreLabel = SKLabelNode()
        // Initialize objects during first start
        public override func sceneDidLoad() {
            super.sceneDidLoad()
            var resr = SKShapeNode()
            scoreLabel.fontSize = 40
            scoreLabel.position = CGPoint(x: 600, y: height - 100)
            HighScoreLabel.fontSize = 40
            HighScoreLabel.fontName = "AvenirNext-Bold"
            scoreLabel.fontName = "AvenirNext-Bold"
            HighScoreLabel.position = CGPoint(x: 200, y: height - 100)
            backButton.position = CGPoint(x: 740, y: height - 60)
            backButton.fontSize = 40
            backButton.fontName = "AvenirNext-Bold"
            self.addChild(HighScoreLabel)
            self.addChild(scoreLabel)
            self.addChild(backButton)
            createWalls()
            createBall(position: CGPoint(x: width / 2, y: height / 2))
            createRacket()
            startNewGame()
            self.physicsWorld.contactDelegate = self
        }
        // Create the ball sprite
        func createBall(position: CGPoint) {
            let physicsBody = SKPhysicsBody(circleOfRadius: ballRadius)
            ball = SKShapeNode(circleOfRadius: ballRadius)
            physicsBody.categoryBitMask = CollisionTypes.Ball.rawValue
            physicsBody.collisionBitMask = CollisionTypes.Wall.rawValue | CollisionTypes.Ball.rawValue | CollisionTypes.Racket.rawValue
            physicsBody.affectedByGravity = false
            physicsBody.restitution = 1
            physicsBody.linearDamping = 0
            physicsBody.velocity = CGVector(dx: -500, dy: 500)
            ball!.physicsBody = physicsBody
            ball!.position = position
            ball!.fillColor = SKColor.white
        }
        // Create the walls
        func createWalls() {
            createWall(rect: CGRect(origin: CGPoint(x: 0, y: 0), size: CGSize(width: ballRadius, height: height)))
            createWall(rect: CGRect(origin: CGPoint(x: 0, y: 0), size: CGSize(width: width, height: ballRadius)))
            createWall(rect: CGRect(origin: CGPoint(x: 0, y: height - ballRadius), size: CGSize(width: width, height: ballRadius)))
        }
        func createWall(rect: CGRect) {
            let node = SKShapeNode(rect: rect)
            node.fillColor = SKColor.white
            node.physicsBody = getWallPhysicsbody(rect: rect)
            self.addChild(node)
        }
        // Create the physics objetcs to handle wall collisions
        func getWallPhysicsbody(rect: CGRect) -> SKPhysicsBody {
            let physicsBody = SKPhysicsBody(rectangleOf: rect.size, center: CGPoint(x: rect.midX, y: rect.midY))
            physicsBody.affectedByGravity = false
            physicsBody.isDynamic = false
            physicsBody.collisionBitMask = CollisionTypes.Ball.rawValue
            physicsBody.categoryBitMask = CollisionTypes.Wall.rawValue
            return physicsBody
        }
        // Create the racket sprite
        func createRacket() {
            racket =  SKShapeNode(rect: CGRect(origin: CGPoint.zero, size: CGSize(width: ballRadius, height: racketHeight)))
            self.addChild(racket!)
            racket!.fillColor = SKColor.white
            let physicsBody = SKPhysicsBody(rectangleOf: racket!.frame.size, center: CGPoint(x: racket!.frame.midX, y: racket!.frame.midY))
            physicsBody.affectedByGravity = false
            physicsBody.isDynamic = false
            physicsBody.collisionBitMask = CollisionTypes.Ball.rawValue
            physicsBody.categoryBitMask = CollisionTypes.Racket.rawValue
            physicsBody.contactTestBitMask = CollisionTypes.Ball.rawValue
            racket!.physicsBody = physicsBody
        }
        // Start a new game
        func startNewGame() {
            score = 0
            scoreLabel.text = "Current Score : \(score)"
            HighScoreLabel.text = "Hight Score : \(HighScore)"
            racket!.position = CGPoint(x: width - ballRadius * 2, y: height / 2)
            backButton.text = "Back"
            var counter = 3
            let startLabel = SKLabelNode(text: "Game Over")
            startLabel.fontName = "AvenirNext-Bold"
            startLabel.position = CGPoint(x: width / 2, y: height / 2)
            startLabel.fontSize = 160
            self.addChild(startLabel)
            // Animated countdown
            let fadeIn = SKAction.fadeIn(withDuration: 0.5)
            let fadeOut = SKAction.fadeOut(withDuration: 0.5)
            startLabel.text = "3"
            self.playbeep()
            startLabel.run(SKAction.sequence([fadeIn, fadeOut]), completion: {
                startLabel.text = "2"
                self.playbeep()
                startLabel.run(SKAction.sequence([fadeIn, fadeOut]), completion: {
                    startLabel.text = "1"
                    self.playbeep()
                    startLabel.run(SKAction.sequence([fadeIn, fadeOut]), completion: {
                        startLabel.text = "0"
                        self.playbeep()
                        startLabel.run(SKAction.sequence([fadeIn, fadeOut]), completion: {
                            startLabel.text = "Start"
                            self.playboop()
                            startLabel.run(SKAction.sequence([fadeIn, fadeOut]),completion: {
                                startLabel.removeFromParent()
                                self.playBacktrack()
                                self.gameRunning = true
                                self.ball!.position = CGPoint(x: 30, y: height / 2)
                                self.addChild(self.ball!)
                            })
                        })
                    })
                })
            })
        }
//: ### Touch Movements
        // Handle touch events to move the racket
        public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            for touch in touches {
                var location = touch.location(in: self)
                if location.y > height / 2 {
                    direction = RacketDirection.Up
                } else if location.y < height / 2{
                    direction = RacketDirection.Down
                }
                if location.y >= height - 100 && location.x >= 600{
                    openMainPage()
                }
            }
        }
        // Stop racket movement
        public override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
            direction = RacketDirection.None
        }
        // Game loop:
        // - Game over check: Ball still on screen
        // - Trigger racket movement
        var dt = TimeInterval(0)
        public override func update(_ currentTime: TimeInterval) {
            if gameRunning {
                super.update(currentTime)
                checkGameOver()
                if dt > 0 {
                    moveRacket(dt: currentTime - dt)
                }
                dt = currentTime
            }
        }
        // Move the racket up or down
        func moveRacket(dt: TimeInterval) {
            if direction == RacketDirection.Up && racket!.position.y < height - racketHeight {
                racket!.position.y = racket!.position.y + CGFloat(racketSpeed * dt)
            } else if direction == RacketDirection.Down && racket!.position.y > 0 {
                racket!.position.y = racket!.position.y - CGFloat(racketSpeed * dt)
            }
        }
        
//: ### Game Over Function
        // Check if the ball is still on screen
        // Game Over animation
        func checkGameOver() {
            if ball!.position.x > CGFloat(width) {
                gameRunning = false
                ball!.removeFromParent()
                let gameOverLabel = SKLabelNode(text: "Game Over")
                
                gameOverLabel.fontName = "AvenirNext-Bold"
                gameOverLabel.position = CGPoint(x: width / 2, y: height / 2)
                gameOverLabel.fontSize = 80
                self.addChild(gameOverLabel)
                self.playboop()
                gameOverLabel.run(SKAction.scale(to: 1, duration: 2.5), completion: {
                    
                    gameOverLabel.removeFromParent()
                    self.startNewGame()
                })
                
                
            }
        }
        
        // Detect collisions between ball and racket to increase the score
        public func didBegin(_ contact: SKPhysicsContact) {
            if contact.bodyA.categoryBitMask == CollisionTypes.Racket.rawValue || contact.bodyB.categoryBitMask == CollisionTypes.Racket.rawValue {
                score += 1
                
                if score > HighScore {
                    HighScore = score
                }
                HighScoreLabel.text = String("High Score : \(HighScore)")
                
                scoreLabel.text = String("Current Score : \(score)")
            }
        }
//: ### Color Jump Music
        var audioPlayer: AVAudioPlayer?
        
        func playBacktrack() {
            if let audioURL = Bundle.main.url(forResource: "Pong Backtrack", withExtension: "mp3") {
                do {
                    try self.audioPlayer = AVAudioPlayer(contentsOf: audioURL) /// make the audio player
                    self.audioPlayer?.numberOfLoops = 10000
                    self.audioPlayer?.setVolume(0.3, fadeDuration: 0)
                    self.audioPlayer?.play() /// start playing
                    
                } catch {
                    print("Couldn't play audio. Error: \(error)")
                }
                
            } else {
                print("No audio file found")
            }
        }
        func playbeep() {
            if let audioURL = Bundle.main.url(forResource: "Pong Beep", withExtension: "m4a") {
                do {
                    try self.audioPlayer = AVAudioPlayer(contentsOf: audioURL) /// make the audio player
                    self.audioPlayer?.numberOfLoops = 0/// Number of times to loop the audio
                    self.audioPlayer?.play() /// start playing
                    
                } catch {
                    print("Couldn't play audio. Error: \(error)")
                }
                
            } else {
                print("No audio file found")
            }
        }
        func playboop() {
            if let audioURL = Bundle.main.url(forResource: "Pong Boop", withExtension: "m4a") {
                do {
                    try self.audioPlayer = AVAudioPlayer(contentsOf: audioURL) /// make the audio player
                    self.audioPlayer?.numberOfLoops = 0 /// Number of times to loop the audio
                    self.audioPlayer?.play() /// start playing
                    
                } catch {
                    print("Couldn't play audio. Error: \(error)")
                }
            } else {
                print("No audio file found")
            }
        }
    }
//: ## Tic-Tac-Toe
    var turn = true
var gamestatus : Bool = true
var l = 1000
//: ### Tic-Tac-Toe Board
    public class Space: UIView {
        var selection = "empty"
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            
        }
        
        convenience init(paperWidth: CGFloat, row: Int, col: Int) {
            let width = paperWidth / 3
            let x = CGFloat(row) * width
            let y = CGFloat(col) * width
            let frame = CGRect(x:x, y: y, width: width, height: width)
            self.init(frame:frame)
            superSpace(row: row, col: col)
            
            let tap = UITapGestureRecognizer(target: self, action: #selector(Space.didTap(_:)))
            self.addGestureRecognizer(tap)
            let swipe = UISwipeGestureRecognizer(target: self, action: #selector(Space.respondToSwipeGesture(gesture:)))
            self.addGestureRecognizer(swipe)
        }
        
        func superSpace(row: Int, col: Int) {
            if row % 2 == col % 2 {
                self.backgroundColor = #colorLiteral(red: 0.501960814, green: 0.501960814, blue: 0.501960814, alpha: 1)
            }
            else {
                self.backgroundColor = #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)
            }
        }
        
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("NSCoding not supported")
        }
        
        func setSelection(change: String) {
            if selection == "empty" {
                let selectionFrame = CGRect(x: self.frame.width / 4, y: self.frame.width / 4, width: self.frame.width / 2, height: self.frame.height / 2)
                
                let selectionView = UIImageView(frame: selectionFrame)
                let backbutton = UIImageView(image: #imageLiteral(resourceName: "tictactoe.png"))
                let XImage = UIImage(named: "x")
                let OImage = UIImage(named: "o")
                
                if change == "x" {
                    selection = "x"
                    playtap()
                    selectionView.image = XImage
                }
                
                else {
                    selection = "o"
                    playtap()
                    selectionView.image = OImage
                }
                
                turn = !turn
                
                UIView.transition(with: self, duration: 0.5, options: [.transitionCrossDissolve, .curveEaseOut], animations: {
                    self.addSubview(selectionView)
                }, completion: nil )
                
            }
            else {
                print("Space is taken!")
            }
        }
        
        func setWin(x: Bool) {
            let selectionFrame = CGRect(x: 0, y: 0, width: self.frame.width, height: self.frame.height)
            
            let winFrame = UIView(frame: selectionFrame)
            
            if (x) {
                winFrame.backgroundColor = #colorLiteral(red: 0.9254902005, green: 0.2352941185, blue: 0.1019607857, alpha: 0.5)
                playwin()
            }
            else {
                winFrame.backgroundColor = #colorLiteral(red: 0.2196078449, green: 0.007843137719, blue: 0.8549019694, alpha: 0.4958350579)
                playwin()
            }
            
            UIView.transition(with: self, duration: 1, options: [.transitionCrossDissolve, .curveEaseOut], animations: {
                self.addSubview(winFrame)
            }, completion: nil )
            
            
        }
        
        func getSelection() -> String {
            return selection
        }
        
        @objc func didTap(_ sender: UITapGestureRecognizer) {
            let controller = PlaygroundPage.current.liveView as! thisGame
            
            let row = Int(sender.location(in: controller).x / self.frame.width)
            let col = Int(sender.location(in: controller).y / self.frame.width)
            
            if turn {
                setSelection(change: "x")
                playtap()
            }
            else {
                setSelection(change: "o")
                playtap()
            }
            
            controller.winner(row: row, col: col)
        }
        @objc func respondToSwipeGesture(gesture: UIGestureRecognizer) {

            if let swipeGesture = gesture as? UISwipeGestureRecognizer {

                switch swipeGesture.direction {
                case .right:
                    openMainPage()
                    
                default:
                    break
                }
            }
        }
        var audioPlayer: AVAudioPlayer?
        func playtictactoeTheme() {
            if let audioURL = Bundle.main.url(forResource: "tictactoe theme", withExtension: "m4a") {
                do {
                    try self.audioPlayer = AVAudioPlayer(contentsOf: audioURL)
                    self.audioPlayer?.numberOfLoops = 10000
                    self.audioPlayer?.setVolume(0.3, fadeDuration: 0)
                    self.audioPlayer?.play() /// start playing
                    
                } catch {
                    print("Couldn't play audio. Error: \(error)")
                }
                
            } else {
                print("No audio file found")
            }
        }
        func playtap() {
            if let audioURL = Bundle.main.url(forResource: "Pong Beep", withExtension: "m4a") {
                do {
                    try self.audioPlayer = AVAudioPlayer(contentsOf: audioURL) /// make the audio player
                    self.audioPlayer?.numberOfLoops = 0/// Number of times to loop the audio
                    self.audioPlayer?.play() /// start playing
                    
                } catch {
                    print("Couldn't play audio. Error: \(error)")
                }
                
            } else {
                print("No audio file found")
            }
        }
        func playwin() {
            if let audioURL = Bundle.main.url(forResource: "tictactoe win", withExtension: "m4a") {
                do {
                    try self.audioPlayer = AVAudioPlayer(contentsOf: audioURL) /// make the audio player
                    self.audioPlayer?.numberOfLoops = 0 /// Number of times to loop the audio
                    self.audioPlayer?.play() /// start playing
                    
                } catch {
                    print("Couldn't play audio. Error: \(error)")
                }
            } else {
                print("No audio file found")
            }
        }


    }

//: ### Game View
    public class thisGame: UIView {
        var paper = Array(repeating: Array(repeating: Space(), count: 3), count: 3)
        override init(frame: CGRect) {
            super.init(frame: frame)
        }
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) not implemented")
        }
        convenience init() {
            let viewFrame = CGRect(x: 0, y: 0, width: 600, height: 600)
            self.init(frame: viewFrame)
            playtictactoeTheme()
            self.backgroundColor = .white
            resetPaper(first: true)
        }
        @objc func resetPaper(first: Bool) {
            for view in self.subviews {
                UIView.transition(with: self, duration: 1, options: [.transitionFlipFromTop, .curveEaseOut], animations: {
                    view.removeFromSuperview()
                }, completion: nil)
            }
            for row in 0...2 {
                for col in 0...2 {
                    paper[row][col] = Space(paperWidth: self.frame.width, row: row, col: col)
                    self.addSubview(paper[row][col])
                }
            }
        }
        func winner(row: Int, col: Int) {
            var winningMoves = [[Int]]()
            var totalCount = 0
            if paper[0][col].getSelection() == paper[1][col].getSelection() && paper[1][col].getSelection() == paper[2][col].getSelection() && paper[0][col].getSelection() != "empty" {
                winningMoves += [[0, col], [1, col], [2, col]]
            }
            else if paper[row][0].getSelection() == paper[row][1].getSelection() && paper[row][1].getSelection() == paper[row][2].getSelection() && paper[row][0].getSelection() != "empty" {
                winningMoves += [[row, 0], [row, 1], [row, 2]]
            }
            else if paper[0][0].getSelection() == paper[1][1].getSelection() && paper[1][1].getSelection() == paper[2][2].getSelection() && paper[0][0].getSelection() != "empty" {
                winningMoves += [[0, 0], [1, 1], [2, 2]]
            }
            else if paper[2][0].getSelection() == paper[1][1].getSelection() && paper[1][1].getSelection() == paper[0][2].getSelection() && paper[2][0].getSelection() != "empty" {
                winningMoves += [[2, 0], [1, 1], [0, 2]]
            }
            else {
                for spaces in paper {
                    for space in spaces {
                        if space.getSelection() == "x" || space.getSelection() == "o" {
                            totalCount += 1
                        }
                    }
                }
            }
            for move in winningMoves {
                paper[move[0]][move[1]].setWin(x: !turn)
            }
            if !winningMoves.isEmpty || totalCount == 9 {
                
                Timer.scheduledTimer(timeInterval: 3, target: self, selector: #selector(resetPaper), userInfo: nil, repeats: false)
                
                for spaces in paper {
                    for space in spaces {
                        space.isUserInteractionEnabled = false
                    }
                }
            }
        }
        var audioPlayer: AVAudioPlayer?
        func playtictactoeTheme() {
            if let audioURL = Bundle.main.url(forResource: "tictactoe theme", withExtension: "mp3") {
                do {
                    try self.audioPlayer = AVAudioPlayer(contentsOf: audioURL)
                    self.audioPlayer?.numberOfLoops = 10000
                    self.audioPlayer?.setVolume(0.3, fadeDuration: 0)
                    self.audioPlayer?.play() /// start playing
                    
                } catch {
                    print("Couldn't play audio. Error: \(error)")
                }
                
            } else {
                print("No audio file found")
            }
        }
        func playtap() {
            if let audioURL = Bundle.main.url(forResource: "Pong Beep", withExtension: "m4a") {
                do {
                    try self.audioPlayer = AVAudioPlayer(contentsOf: audioURL) /// make the audio player
                    self.audioPlayer?.numberOfLoops = 0/// Number of times to loop the audio
                    self.audioPlayer?.play() /// start playing
                    
                } catch {
                    print("Couldn't play audio. Error: \(error)")
                }
                
            } else {
                print("No audio file found")
            }
        }
        func playwin() {
            if let audioURL = Bundle.main.url(forResource: "tictactoe win", withExtension: "m4a") {
                do {
                    try self.audioPlayer = AVAudioPlayer(contentsOf: audioURL) /// make the audio player
                    self.audioPlayer?.numberOfLoops = 0 /// Number of times to loop the audio
                    self.audioPlayer?.play() /// start playing
                    
                } catch {
                    print("Couldn't play audio. Error: \(error)")
                }
            } else {
                print("No audio file found")
            }
        }



        
    
    }


